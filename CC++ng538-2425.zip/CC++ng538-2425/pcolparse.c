#include <stdio.h>
#include "pcolparse.h"
//ng538
void fill_IP_header(IP_Header* ip_header_ptr, FILE* log_file_ptr) {
    unsigned char word_buffer[4];
    fread(word_buffer, 1, 4, log_file_ptr);

    ip_header_ptr->version = word_buffer[0] >> 4;
    ip_header_ptr->IHL = word_buffer[0];
    ip_header_ptr->type_of_service = word_buffer[1];
    ip_header_ptr->total_length = word_buffer[2] << 8 | word_buffer[3];

    unsigned int remaining_words = ip_header_ptr->IHL - 1;
    unsigned char buffer[4 * remaining_words];
    fread(buffer, 1, 4 * remaining_words, log_file_ptr);

    ip_header_ptr->identification = buffer[0] << 8 | buffer[1];
    ip_header_ptr->flags = buffer[2] >> 5;
    ip_header_ptr->fragment_offset = buffer[2] << 8 | buffer[3];
    ip_header_ptr->time_to_live = buffer[4];
    ip_header_ptr->protocol = buffer[5];
    ip_header_ptr->header_checksum = buffer[6] << 8 | buffer[7];
    ip_header_ptr->source_address = buffer[8] << 24 | buffer[9] << 16 | buffer[10] << 8 | buffer[11];
    ip_header_ptr->destination_address = buffer[12] << 24 | buffer[13] << 16 | buffer[14] << 8 | buffer[15];
}

void fill_TCP_header(TCP_Header* tcp_header_ptr, FILE* log_file_ptr) {
    unsigned char word_buffer[4];
    fread(word_buffer, 1, 4, log_file_ptr);

    tcp_header_ptr->source_port = word_buffer[0] << 8 | word_buffer[1];
    tcp_header_ptr->destination_port = word_buffer[2] << 8 | word_buffer[3];

    fread(word_buffer, 1, 4, log_file_ptr);

    tcp_header_ptr->sequence_number = word_buffer[0] << 24 | word_buffer[1] << 16 | word_buffer[2] << 8 | word_buffer[3];
    
    fread(word_buffer, 1, 4, log_file_ptr);
    
    tcp_header_ptr->acknowledgment_number = word_buffer[0] << 24 | word_buffer[1] << 16 | word_buffer[2] << 8 | word_buffer[3];

    fread(word_buffer, 1, 4, log_file_ptr);

    tcp_header_ptr->data_offset = word_buffer[0] >> 4;
    tcp_header_ptr->reserved = word_buffer[0] << 8 | word_buffer[1];
    tcp_header_ptr->window = word_buffer[2] << 8 | word_buffer[3];

    unsigned int remaining_words = tcp_header_ptr->data_offset - 4;
    unsigned char buffer[4 * remaining_words];
    fread(buffer, 1, 4 * remaining_words, log_file_ptr);

    tcp_header_ptr->checksum = buffer[0] << 8 | buffer[1];
    tcp_header_ptr->urgent_pointer = buffer[2] << 8 | buffer[3];
}
