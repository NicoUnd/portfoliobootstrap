#include <stdio.h>
#include "pcolparse.h"
//ng538
void print_IP(unsigned int IP){
  printf("%u.%u.%u.%u ", (unsigned char)(IP >> 24), (unsigned char)(IP >> 16), (unsigned char)(IP >> 8), (unsigned char)IP);
}

int main(int argc, const char * argv[]) {
    if (argc != 2) {
        perror("Dosage: <IP_PACKET_FILE>");
        return 1;
    }

    FILE *log_file_ptr = fopen(argv[1], "r");

    fseek(log_file_ptr, 0, SEEK_END);
    fseek(log_file_ptr, 0, SEEK_END);    unsigned long log_file_size = ftell(log_file_ptr);
    fseek(log_file_ptr, 0, SEEK_SET);

    IP_Header IP_header;
    TCP_Header TCP_header;

    unsigned long sum_of_size = 0;
    unsigned int num_of_packets = 0;
    while (sum_of_size < log_file_size){
        fill_IP_header(&IP_header, log_file_ptr);
	fill_TCP_header(&TCP_header, log_file_ptr);

	if (num_of_packets == 1){
	  print_IP(IP_header.source_address);
          print_IP(IP_header.destination_address);
          printf("%u ", IP_header.IHL);
          printf("%u ", IP_header.total_length);
          printf("%u ", TCP_header.data_offset);
        }
        //printf("TOTAL LEN: %d ", IP_header.total_length);
	//printf("IHL: %d ", IP_header.IHL);
	//printf("DATA OFFSET: %d ", TCP_header.data_offset);
        sum_of_size += IP_header.total_length;
	unsigned int rest_of_packet_length = IP_header.total_length - IP_header.IHL * 4 - TCP_header.data_offset * 4;
        //printf("REST OF PACKET LEN: %d ", rest_of_packet_length);
	unsigned char discard[rest_of_packet_length];
        int successful_read = fread(discard, 1, rest_of_packet_length, log_file_ptr);

        num_of_packets += 1;
    }
    printf("%u\n", num_of_packets);
}
