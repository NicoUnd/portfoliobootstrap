#include <stdio.h>
#include <iostream>
#include <fstream>
#include "pcolparse.h"
//ng538
int main(int argc, const char * argv[]) {
  if (argc != 3) {
    perror("Dosage: <LOG_FILE> <WRITE_TO_FILE>");
    return 1;
  }

  FILE* log_file_ptr = fopen(argv[1], "r");
  if (log_file_ptr == nullptr){
    perror("Cannot find log file");
  }

  fseek(log_file_ptr, 0, SEEK_END);
  unsigned long log_file_size = ftell(log_file_ptr);
  fseek(log_file_ptr, 0, SEEK_SET);

  //FILE* write_file_ptr = fopen(argv[2], "w");
  std::ofstream file(argv[2], std::ios::binary);

  unsigned long sum_of_size = 0;
  while (sum_of_size < log_file_size){
    IP_Header IP_header;
    fill_IP_header(&IP_header, log_file_ptr);

    TCP_Header TCP_header;
    fill_TCP_header(&TCP_header, log_file_ptr);

    sum_of_size += IP_header.total_length;
    unsigned int rest_of_packet_length = IP_header.total_length - IP_header.IHL * 4 - TCP_header.data_offset * 4;

    unsigned char packet_data[rest_of_packet_length];
    int successful_read = fread(packet_data, 1, rest_of_packet_length, log_file_ptr);

    //fwrite(write_file_ptr, packet_data);
    file.write(reinterpret_cast<const char*>(packet_data), rest_of_packet_length);
  }
  file.close();
}
