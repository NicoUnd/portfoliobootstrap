// ng538  watermark=90a4f57658a466462d35ba8feb362180
/* client.c */
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>

#define BUFSIZE 512

int main(int argc, char *argv[])
{
  if (argc != 3) {
    perror("Dosage: client <host> <port>");
    return 1;
  }

  int sockfd;  
  if ((sockfd = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP)) < 0) {
    perror("Cannot create socket.");
    return 2;
  }

  struct sockaddr_in servaddr;  
  memset(&servaddr,0,sizeof(servaddr));
  servaddr.sin_port = htons(atoi(argv[2]));
  servaddr.sin_family = AF_INET;
  servaddr.sin_addr.s_addr = inet_addr(argv[1]);

  if (connect(sockfd,(struct sockaddr *) &servaddr,sizeof(servaddr)) < 0) {
    perror("Cannot connect to server.");
    return 3;
  }

  int nb;
  char bytes[BUFSIZE-1];
  while((nb = read(sockfd,bytes,BUFSIZE)) > 0) fwrite(bytes, nb, sizeof(char), stdout);
  return 1;
}
// ng538  watermark=90a4f57658a466462d35ba8feb362180
